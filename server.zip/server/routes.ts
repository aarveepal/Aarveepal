import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import express from "express";
import { storage } from "./storage";
import { insertContactSchema, insertCertificateSchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({
  dest: path.join(process.cwd(), "client/public/documents/"),
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      
      // In a real application, you would send an email here
      // using nodemailer or similar service
      
      res.json({ 
        success: true, 
        message: "Message sent successfully!",
        contact: contact 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Invalid form data",
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Failed to send message" 
        });
      }
    }
  });

  // Get all certificates
  app.get("/api/certificates", async (req, res) => {
    try {
      const certificates = await storage.getCertificates();
      res.json(certificates);
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch certificates" 
      });
    }
  });

  // Upload new certificate
  app.post("/api/certificates", upload.single("certificate"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ 
          success: false, 
          message: "No file uploaded" 
        });
      }

      const certificateData = insertCertificateSchema.parse({
        ...req.body,
        filename: req.file.filename,
      });

      const certificate = await storage.createCertificate(certificateData);
      
      res.json({ 
        success: true, 
        message: "Certificate uploaded successfully!",
        certificate: certificate 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Invalid certificate data",
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Failed to upload certificate" 
        });
      }
    }
  });

  // Download certificate
  app.get("/api/certificates/:id/download", async (req, res) => {
    try {
      const certificate = await storage.getCertificate(req.params.id);
      if (!certificate) {
        return res.status(404).json({ 
          success: false, 
          message: "Certificate not found" 
        });
      }

      const filePath = path.join(process.cwd(), "client/public/documents/", certificate.filename);
      res.download(filePath, `${certificate.title}.pdf`);
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to download certificate" 
      });
    }
  });

  // Serve static files from documents directory
  app.use("/documents", express.static(path.join(process.cwd(), "client/public/documents/")));

  const httpServer = createServer(app);
  return httpServer;
}
