import { type User, type InsertUser, type Contact, type InsertContact, type Certificate, type InsertCertificate } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createContact(contact: InsertContact): Promise<Contact>;
  getCertificates(): Promise<Certificate[]>;
  createCertificate(certificate: InsertCertificate): Promise<Certificate>;
  getCertificate(id: string): Promise<Certificate | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private contacts: Map<string, Contact>;
  private certificates: Map<string, Certificate>;

  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.certificates = new Map();
    
    // Initialize with default certificates
    this.initializeDefaultCertificates();
  }

  private initializeDefaultCertificates() {
    const defaultCertificates: Certificate[] = [
      {
        id: randomUUID(),
        title: "Brand Management Certification",
        organization: "Phoenix Global",
        description: "Knowledge in brand strategy, positioning, and consumer behavior. Practical insights into CBBE model, campaign development, ROI analysis, and employer/social branding.",
        filename: "brand-management-cert.pdf",
        uploadedAt: new Date(),
      },
      {
        id: randomUUID(),
        title: "Digital Marketing Core Certification",
        organization: "Google (IAB Certified)",
        description: "SEO, SEM, email marketing, content strategy, web analytics, and social media. Validated core skills in online promotion and customer engagement.",
        filename: "digital-marketing-cert.pdf",
        uploadedAt: new Date(),
      },
      {
        id: randomUUID(),
        title: "Product Management Program",
        organization: "Phoenix Global",
        description: "Market research, feature ideation, and product analytics. GTM strategies and tech-driven decision-making for competitive, user-focused products.",
        filename: "product-management-cert.pdf",
        uploadedAt: new Date(),
      },
      {
        id: randomUUID(),
        title: "CHR-G HR Certification",
        organization: "Koed Learnings",
        description: "Core HR functions including recruitment, employee relations, payroll, and compliance. Expertise in HRBP practices, statutory compliance, and performance management systems.",
        filename: "hr-certification.pdf",
        uploadedAt: new Date(),
      },
    ];

    defaultCertificates.forEach(cert => {
      this.certificates.set(cert.id, cert);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id,
      createdAt: new Date(),
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getCertificates(): Promise<Certificate[]> {
    return Array.from(this.certificates.values());
  }

  async createCertificate(insertCertificate: InsertCertificate): Promise<Certificate> {
    const id = randomUUID();
    const certificate: Certificate = {
      ...insertCertificate,
      id,
      uploadedAt: new Date(),
    };
    this.certificates.set(id, certificate);
    return certificate;
  }

  async getCertificate(id: string): Promise<Certificate | undefined> {
    return this.certificates.get(id);
  }
}

export const storage = new MemStorage();
