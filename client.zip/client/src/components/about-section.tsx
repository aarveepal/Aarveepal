export default function AboutSection() {
  return (
    <section className="section-padding bg-muted/30" id="about">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-8" data-testid="about-heading">
            About Me
          </h2>
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <p className="text-lg text-muted-foreground leading-relaxed" data-testid="about-text-1">
              I'm Aarvee, an MBA candidate at{" "}
              <span className="font-semibold text-foreground">IIM Kashipur (2025–27)</span>{" "}
              with a background in B.Sc. Chemistry. My academic path built a strong analytical foundation, and my management journey is shaping my skills in marketing and strategy.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed mt-6" data-testid="about-text-2">
              I'm particularly interested in how brands connect with people and how structured problem-solving can drive business impact. I bring qualities of resilience, adaptability, and curiosity, and aim to contribute meaningfully to impactful marketing projects.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
