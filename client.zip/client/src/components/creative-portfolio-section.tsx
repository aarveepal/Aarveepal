import { Palette, Smartphone, Edit } from "lucide-react";

export default function CreativePortfolioSection() {
  return (
    <section className="section-padding creative-portfolio-bg" id="creative-portfolio">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="creative-portfolio-heading">
            <span className="mr-3">✏️</span>
            Creative Writing & Visual Storytelling
            <span className="ml-3">🎨</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Showcasing brand storytelling, creative campaigns, and visual content. Mini-campaigns, brand narratives, social media captions, and content creations to be added soon.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand Storytelling */}
          <div className="bg-card/60 rounded-xl p-8 shadow-lg border border-border card-hover" data-testid="creative-card-0">
            <div className="text-center">
              <Edit className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-bold text-foreground mb-3">
                Brand Storytelling
              </h3>
              <p className="text-muted-foreground">
                Creative narratives and brand voice development
              </p>
            </div>
          </div>

          {/* Social Media Campaigns */}
          <div className="bg-card/60 rounded-xl p-8 shadow-lg border border-border card-hover" data-testid="creative-card-1">
            <div className="text-center">
              <Smartphone className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-bold text-foreground mb-3">
                Social Media Campaigns
              </h3>
              <p className="text-muted-foreground">
                Engaging content and campaign strategies
              </p>
            </div>
          </div>

          {/* Visual Content */}
          <div className="bg-card/60 rounded-xl p-8 shadow-lg border border-border card-hover" data-testid="creative-card-2">
            <div className="text-center">
              <Palette className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-bold text-foreground mb-3">
                Visual Content
              </h3>
              <p className="text-muted-foreground">
                Design thinking and visual communication
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
