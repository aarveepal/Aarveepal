import { Mail, MapPin, Clock, Linkedin, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { scrollToSection } from "@/lib/scroll-utils";

export default function FooterSection() {
  const handleDownloadResume = () => {
    // In a real implementation, this would download the actual resume
    console.log("Download resume clicked");
  };

  const navigationLinks = [
    { label: "About Me", href: "about" },
    { label: "Live Projects", href: "projects" },
    { label: "Certificates", href: "certificates" },
    { label: "Skills", href: "skills" },
    { label: "Contact", href: "contact" },
  ];

  return (
    <footer className="bg-foreground text-background py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8 text-center md:text-left">
          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-4" data-testid="footer-contact-heading">
              Contact Info
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-center md:justify-start">
                <Mail className="mr-3 h-4 w-4" />
                <a
                  href="mailto:aarveepal5@gmail.com"
                  className="hover:text-primary transition-colors"
                  data-testid="footer-email"
                >
                  aarveepal5@gmail.com
                </a>
              </div>
              <div className="flex items-center justify-center md:justify-start">
                <MapPin className="mr-3 h-4 w-4" />
                <span data-testid="footer-location">IIM Kashipur, India</span>
              </div>
              <div className="flex items-center justify-center md:justify-start">
                <Clock className="mr-3 h-4 w-4" />
                <span data-testid="footer-availability">Open for Internships & Live Projects</span>
              </div>
            </div>
          </div>

          {/* Professional Links */}
          <div>
            <h3 className="text-xl font-bold mb-4" data-testid="footer-links-heading">
              Professional Links
            </h3>
            <div className="space-y-4">
              <a
                href="https://www.linkedin.com/in/aarvee-pal-432329247/"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-hover inline-flex items-center bg-primary text-primary-foreground px-6 py-2 rounded-lg font-medium"
                data-testid="footer-linkedin"
              >
                <Linkedin className="mr-2 h-4 w-4" />
                LinkedIn Profile
              </a>
              <br />
              <Button
                onClick={handleDownloadResume}
                className="btn-hover bg-secondary text-secondary-foreground px-6 py-2 rounded-lg font-medium"
                data-testid="footer-resume"
              >
                <Download className="mr-2 h-4 w-4" />
                Download Resume
              </Button>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h3 className="text-xl font-bold mb-4" data-testid="footer-nav-heading">
              Quick Navigation
            </h3>
            <div className="space-y-2">
              {navigationLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => scrollToSection(link.href)}
                  className="block hover:text-primary transition-colors"
                  data-testid={`footer-nav-${link.href}`}
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-muted-foreground/20 mt-8 pt-8 text-center">
          <p className="text-muted-foreground" data-testid="footer-copyright">
            &copy; 2025 Aarvee Pal. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
