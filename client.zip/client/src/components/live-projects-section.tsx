import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export default function LiveProjectsSection() {
  const projects = [
    {
      title: "Brand Management — International Market Entry Strategy",
      result: "Conducted market research using the STP framework, identified two high-potential consumer segments in Nepal's Bluetooth speaker market, and built a differentiated positioning strategy with 6 targeted campaigns and contingency plans.",
      learning: "Discovered that segmentation works best when grounded in real consumer lifestyles, that brand personality drives all touchpoints, and that cultural alignment (trekking & festivals) strengthens resonance.",
      takeaway: "Learned that a strong brand isn't just about products—it's about creating emotions and experiences people connect with.",
    },
    {
      title: "Product Management — Wellness Companion Feature",
      result: "Designed a wellness companion feature for a healthcare technology application by conducting user research (8 interviews), developing personas, and prioritizing features with RICE and Kano frameworks. Delivered prototypes and a go-to-market strategy tailored to Gen Z and young professionals.",
      learning: "Realized that product success depends on solving real user pain points with simple, high-impact solutions. Learned how to balance user privacy with engagement and how success metrics drive adoption and retention.",
      takeaway: "Understood that effective product management is not just about building features, but about aligning research, design, and strategy to create meaningful user experiences.",
    },
    {
      title: "Human Resources — Recruitment Process Mapping",
      result: "Streamlined recruitment by designing an end-to-end hiring workflow that covered sourcing, interviews, compliance, and onboarding, reducing hiring timelines to 2–3 weeks. Standardized templates improved consistency, compliance, and candidate experience.",
      learning: "Learned how structured processes improve efficiency, fairness, and decision-making in hiring. Understood the value of documentation and compliance in building trust and aligning talent acquisition with business goals.",
      takeaway: "Discovered that recruitment is more than filling positions—it's about building a consistent, candidate-friendly process that supports long-term organizational growth.",
    },
  ];

  return (
    <section className="section-padding bg-background" id="projects">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="live-projects-heading">
            Live Projects
          </h2>
          <p className="text-lg text-muted-foreground">
            Real-world projects showcasing strategic thinking and implementation
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-card rounded-xl p-6 shadow-lg border border-border card-hover"
              data-testid={`project-card-${index}`}
            >
              <h3 className="text-xl font-bold text-foreground mb-4" data-testid={`project-title-${index}`}>
                {project.title}
              </h3>

              <div className="space-y-4">
                <div>
                  <h4 className="flex items-center text-sm font-semibold text-accent mb-2">
                    <span className="mr-2">🎯</span> Result
                  </h4>
                  <p className="text-sm text-muted-foreground" data-testid={`project-result-${index}`}>
                    {project.result}
                  </p>
                </div>

                <div>
                  <h4 className="flex items-center text-sm font-semibold text-primary mb-2">
                    <span className="mr-2">📘</span> Learning
                  </h4>
                  <p className="text-sm text-muted-foreground" data-testid={`project-learning-${index}`}>
                    {project.learning}
                  </p>
                </div>

                <div>
                  <h4 className="flex items-center text-sm font-semibold text-secondary mb-2">
                    <span className="mr-2">💡</span> Takeaway
                  </h4>
                  <p className="text-sm text-muted-foreground" data-testid={`project-takeaway-${index}`}>
                    {project.takeaway}
                  </p>
                </div>
              </div>

              <Button
                className="btn-hover w-full mt-6 bg-primary text-primary-foreground py-2 px-4 rounded-lg font-medium"
                data-testid={`button-view-certificate-${index}`}
              >
                <Download className="mr-2 h-4 w-4" />
                View Certificate
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
