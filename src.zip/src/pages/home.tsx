import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import LiveProjectsSection from "@/components/live-projects-section";
import OtherProjectsSection from "@/components/other-projects-section";
import CertificatesSection from "@/components/certificates-section";
import SkillsSection from "@/components/skills-section";
import CreativePortfolioSection from "@/components/creative-portfolio-section";
import ContactSection from "@/components/contact-section";
import FooterSection from "@/components/footer-section";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <LiveProjectsSection />
      <OtherProjectsSection />
      <CertificatesSection />
      <SkillsSection />
      <CreativePortfolioSection />
      <ContactSection />
      <FooterSection />
    </div>
  );
}
