import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { Certificate } from "@shared/schema";

export default function CertificatesSection() {
  const { data: certificates, isLoading } = useQuery<Certificate[]>({
    queryKey: ["/api/certificates"],
  });

  const handleDownload = (certificateId: string) => {
    window.open(`/api/certificates/${certificateId}/download`, "_blank");
  };

  const getIcon = (title: string) => {
    if (title.toLowerCase().includes("brand")) return "🎯";
    if (title.toLowerCase().includes("digital") || title.toLowerCase().includes("marketing")) return "💻";
    if (title.toLowerCase().includes("product")) return "🚀";
    if (title.toLowerCase().includes("hr") || title.toLowerCase().includes("human")) return "👥";
    return "📜";
  };

  if (isLoading) {
    return (
      <section className="section-padding bg-background" id="certificates">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Certificates
            </h2>
            <p className="text-lg text-muted-foreground">
              Professional certifications and continuous learning
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-card rounded-xl p-6 shadow-lg border border-border animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-4"></div>
                <div className="h-3 bg-muted rounded w-1/2 mb-4"></div>
                <div className="h-20 bg-muted rounded mb-4"></div>
                <div className="h-8 bg-muted rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="section-padding bg-background" id="certificates">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="certificates-heading">
            Certificates
          </h2>
          <p className="text-lg text-muted-foreground">
            Professional certifications and continuous learning
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {certificates?.map((certificate, index) => (
            <div
              key={certificate.id}
              className="bg-card rounded-xl p-6 shadow-lg border border-border card-hover"
              data-testid={`certificate-card-${index}`}
            >
              <div className="text-center mb-4">
                <div className="text-4xl mb-3">{getIcon(certificate.title)}</div>
                <h3 className="text-lg font-bold text-foreground mb-2" data-testid={`certificate-title-${index}`}>
                  {certificate.title}
                </h3>
                <p className="text-sm text-primary font-medium" data-testid={`certificate-org-${index}`}>
                  {certificate.organization}
                </p>
              </div>
              <p className="text-sm text-muted-foreground mb-4" data-testid={`certificate-description-${index}`}>
                {certificate.description}
              </p>
              <Button
                onClick={() => handleDownload(certificate.id)}
                className="btn-hover w-full bg-primary text-primary-foreground py-2 px-4 rounded-lg font-medium text-sm"
                data-testid={`button-download-certificate-${index}`}
              >
                <Download className="mr-2 h-4 w-4" />
                View Certificate
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
