import { Briefcase, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { scrollToSection } from "@/lib/scroll-utils";
import aarveePhotoPath from "@assets/aarvee pal photo_1756552323805.png";

export default function HeroSection() {
  return (
    <section className="hero-gradient section-padding pt-24" id="hero">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="mb-8">
            <img
              src={aarveePhotoPath}
              alt="Aarvee Pal Professional Photo"
              className="w-32 h-32 rounded-full mx-auto object-cover border-4 border-primary/20 shadow-lg"
              data-testid="profile-image"
            />
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Hi, I'm Aarvee —<br />
            <span className="text-primary">MBA Candidate</span> |{" "}
            <span className="text-secondary">Marketing Enthusiast</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Passionate about brand management, consumer insights, and product strategy.
          </p>
          
          <div className="bg-card/80 rounded-lg p-6 mb-8 max-w-4xl mx-auto border border-border">
            <p className="text-lg text-muted-foreground">
              Worked on projects including launching a consumer electronics brand in international markets and developing product strategies for healthcare technology.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={() => scrollToSection("projects")}
              className="btn-hover bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold shadow-lg"
              data-testid="button-view-work"
            >
              <Briefcase className="mr-2 h-4 w-4" />
              View My Work
            </Button>
            <Button
              onClick={() => scrollToSection("contact")}
              className="btn-hover bg-secondary text-secondary-foreground px-8 py-3 rounded-lg font-semibold shadow-lg"
              data-testid="button-get-in-touch"
            >
              <Mail className="mr-2 h-4 w-4" />
              Get In Touch
            </Button>
          </div>
          
          <p className="text-sm text-muted-foreground mt-6 italic">
            "Exploring the intersection of creativity and strategy in marketing."
          </p>
        </div>
      </div>
    </section>
  );
}
