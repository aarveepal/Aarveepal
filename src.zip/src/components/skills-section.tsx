export default function SkillsSection() {
  const hardSkills = [
    {
      icon: "💻",
      title: "Social Media Marketing",
      description: "Instagram, LinkedIn campaigns, and engagement strategies",
    },
    {
      icon: "🛠️",
      title: "MS Excel",
      description: "Data analysis, pivot tables, charts, reporting",
    },
    {
      icon: "🎨",
      title: "Canva / CapCut / Photoshop",
      description: "Content creation & visual marketing",
    },
    {
      icon: "📑",
      title: "MS PowerPoint",
      description: "Presentations, pitching campaigns, storytelling",
    },
    {
      icon: "📈",
      title: "SEO & SEM",
      description: "Basic exposure, actively learning",
    },
    {
      icon: "📊",
      title: "Google Analytics",
      description: "Basic exposure, actively learning",
    },
  ];

  const softSkills = [
    { icon: "💡", title: "Creative Thinking & Ideation" },
    { icon: "🤝", title: "Teamwork & Collaboration" },
    { icon: "🧠", title: "Emotional Intelligence" },
    { icon: "🗣", title: "Communication & Storytelling" },
    { icon: "🔍", title: "Problem-Solving & Analytical Mindset" },
  ];

  return (
    <section className="section-padding bg-muted/30" id="skills">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="skills-heading">
            Skills
          </h2>
          <p className="text-lg text-muted-foreground">
            Technical expertise and professional capabilities
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Hard Skills */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <h3 className="text-2xl font-bold text-foreground mb-6 text-center" data-testid="hard-skills-heading">
              Hard Skills
            </h3>
            <div className="space-y-4">
              {hardSkills.map((skill, index) => (
                <div key={index} className="flex items-start" data-testid={`hard-skill-${index}`}>
                  <span className="text-2xl mr-4 mt-1">{skill.icon}</span>
                  <div>
                    <h4 className="font-semibold text-foreground" data-testid={`hard-skill-title-${index}`}>
                      {skill.title}
                    </h4>
                    <p className="text-sm text-muted-foreground" data-testid={`hard-skill-description-${index}`}>
                      {skill.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Soft Skills */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <h3 className="text-2xl font-bold text-foreground mb-6 text-center" data-testid="soft-skills-heading">
              Soft Skills
            </h3>
            <div className="space-y-4">
              {softSkills.map((skill, index) => (
                <div key={index} className="flex items-center" data-testid={`soft-skill-${index}`}>
                  <span className="text-2xl mr-4">{skill.icon}</span>
                  <h4 className="font-semibold text-foreground" data-testid={`soft-skill-title-${index}`}>
                    {skill.title}
                  </h4>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
