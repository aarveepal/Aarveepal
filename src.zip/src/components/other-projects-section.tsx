import { GraduationCap, FileText } from "lucide-react";

export default function OtherProjectsSection() {
  return (
    <section className="section-padding bg-muted/30" id="other-projects">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="other-projects-heading">
            Other Projects
          </h2>
          <p className="text-lg text-muted-foreground">
            Academic work and upcoming initiatives
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Consumer Behaviour Project */}
          <div className="bg-card rounded-xl p-6 shadow-lg border border-border card-hover" data-testid="other-project-card-0">
            <h3 className="text-xl font-bold text-foreground mb-4">
              Consumer Behaviour — College Project
            </h3>

            <div className="space-y-4">
              <div>
                <h4 className="flex items-center text-sm font-semibold text-accent mb-2">
                  <span className="mr-2">🎯</span> Result
                </h4>
                <p className="text-sm text-muted-foreground">
                  Explored consumer decision-making in high-involvement utilitarian products, analyzing satisfaction, loyalty, and repeat purchase behavior. Developed six actionable marketing recommendations to strengthen long-term engagement.
                </p>
              </div>

              <div>
                <h4 className="flex items-center text-sm font-semibold text-primary mb-2">
                  <span className="mr-2">📘</span> Learning
                </h4>
                <p className="text-sm text-muted-foreground">
                  Discovered how factors like trust, experience, and brand value shape consumer-brand relationships, and how threats such as dissatisfaction weaken loyalty.
                </p>
              </div>

              <div>
                <h4 className="flex items-center text-sm font-semibold text-secondary mb-2">
                  <span className="mr-2">💡</span> Takeaway
                </h4>
                <p className="text-sm text-muted-foreground">
                  Realized that consumer behaviour is not just about single purchase decisions—it's about building trust and sustaining long-term brand loyalty.
                </p>
              </div>
            </div>
          </div>

          {/* Coming Soon - Case Studies */}
          <div className="bg-card rounded-xl p-6 shadow-lg border border-border card-hover" data-testid="other-project-card-1">
            <div className="text-center h-full flex flex-col justify-center">
              <div className="text-6xl mb-4">
                <FileText className="w-16 h-16 mx-auto text-muted-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-4">
                Coming Soon — Case Studies
              </h3>
              <p className="text-muted-foreground">
                Placeholder for future case study analyses and strategy breakdowns.
              </p>
            </div>
          </div>

          {/* Upcoming Academic Projects */}
          <div className="bg-card rounded-xl p-6 shadow-lg border border-border card-hover" data-testid="other-project-card-2">
            <div className="text-center h-full flex flex-col justify-center">
              <div className="text-6xl mb-4">
                <GraduationCap className="w-16 h-16 mx-auto text-muted-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-4">
                Upcoming Academic Projects
              </h3>
              <p className="text-muted-foreground">
                Placeholder for future MBA academic projects.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
